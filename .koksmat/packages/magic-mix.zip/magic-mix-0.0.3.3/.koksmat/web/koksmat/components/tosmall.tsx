export default function ToSmall() {
  return <div className="content-center md:hidden">
    <h1 className="scroll-m-20 p-10 text-2xl font-extrabold tracking-tight lg:text-5xl">
      Sorry, your screen size is too small to display this page.
    </h1>


  </div>;
}
