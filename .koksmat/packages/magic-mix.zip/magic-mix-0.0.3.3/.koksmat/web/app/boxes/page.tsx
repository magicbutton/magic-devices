"use client";

export default function Page() {
  return <div className="space-x-2 h-[90vh]"></div>;
}
