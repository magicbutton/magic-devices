
export interface MessageType {
  timestamp: number;
  message: string;
  isError?: boolean;
}
