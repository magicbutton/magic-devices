"use client";
import { MSALTest } from "@/koksmat/msal/test";

export default function Home() {
  return (
    <div className="p-10">
      <MSALTest />
    </div>
  );
}
