export const APPNAME = "files";
export const MSAL = {
  clientId: "3a8bf549-eb49-4c60-912b-bb30cd964574",

  authority:
    "https://login.microsoftonline.com/79dc228f-c8f2-4016-8bf0-b990b6c72e98",
  redirectUri: "/",
  postLogoutRedirectUri: "/",
};
