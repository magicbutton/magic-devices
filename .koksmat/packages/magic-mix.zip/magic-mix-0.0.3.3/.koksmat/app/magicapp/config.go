package magicapp

/*
moved to utils
*/
