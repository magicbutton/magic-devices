package magicapp

import (
	"testing"
)

func TestMongo(t *testing.T) {

	MongoTest()
}
