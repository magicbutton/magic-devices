package schemas

type AllSegments []struct {
	Id    string `json:"id"`
	Title string `json:"title"`
}
