/* 
File have been automatically created. To prevent the file from getting overwritten
set the Front Matter property ´keep´ to ´true´ syntax for the code snippet
---
keep: false
---
*/
//generator:  noma3
package processlog
import (
    "log"
    "errors"
    "github.com/magicbutton/magic-mix/services/models/processlogmodel"
    . "github.com/magicbutton/magic-mix/utils"
)


func ProcessLogSearch(query string ) (*Page[processlogmodel.ProcessLog],error) {
log.Println("Calling ProcessLogSearch")
    
    
    
    return nil,errors.New("Not implemented")




}
    
