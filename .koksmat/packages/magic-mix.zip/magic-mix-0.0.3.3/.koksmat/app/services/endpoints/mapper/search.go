/* 
File have been automatically created. To prevent the file from getting overwritten
set the Front Matter property ´keep´ to ´true´ syntax for the code snippet
---
keep: false
---
*/
//generator:  noma3
package mapper
import (
    "log"
    "errors"
    "github.com/magicbutton/magic-mix/services/models/mappermodel"
    . "github.com/magicbutton/magic-mix/utils"
)


func MapperSearch(query string ) (*Page[mappermodel.Mapper],error) {
log.Println("Calling MapperSearch")
    
    
    
    return nil,errors.New("Not implemented")




}
    
