/* 
File have been automatically created. To prevent the file from getting overwritten
set the Front Matter property ´keep´ to ´true´ syntax for the code snippet
---
keep: false
---
*/
//generator:  noma3
package dataset
import (
    "log"
    "errors"
    "github.com/magicbutton/magic-mix/services/models/datasetmodel"
    . "github.com/magicbutton/magic-mix/utils"
)


func DatasetSearch(query string ) (*Page[datasetmodel.Dataset],error) {
log.Println("Calling DatasetSearch")
    
    
    
    return nil,errors.New("Not implemented")




}
    
