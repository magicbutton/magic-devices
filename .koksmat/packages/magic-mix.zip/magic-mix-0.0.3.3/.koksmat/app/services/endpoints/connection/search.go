/* 
File have been automatically created. To prevent the file from getting overwritten
set the Front Matter property ´keep´ to ´true´ syntax for the code snippet
---
keep: false
---
*/
//generator:  noma3
package connection
import (
    "log"
    "errors"
    "github.com/magicbutton/magic-mix/services/models/connectionmodel"
    . "github.com/magicbutton/magic-mix/utils"
)


func ConnectionSearch(query string ) (*Page[connectionmodel.Connection],error) {
log.Println("Calling ConnectionSearch")
    
    
    
    return nil,errors.New("Not implemented")




}
    
