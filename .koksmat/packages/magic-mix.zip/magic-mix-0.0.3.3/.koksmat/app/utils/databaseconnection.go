package utils

import "github.com/uptrace/bun"

var Db *bun.DB
