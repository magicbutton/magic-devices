package utils

type Identifiable struct {
	ID int
}
