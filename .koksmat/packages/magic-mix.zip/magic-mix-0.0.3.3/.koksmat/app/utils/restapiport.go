package utils

var RestApiPort int = 8080
