package utils

var Verbose bool = false
