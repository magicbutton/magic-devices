package utils

import "github.com/spf13/cobra"

var RootCmd = &cobra.Command{}
