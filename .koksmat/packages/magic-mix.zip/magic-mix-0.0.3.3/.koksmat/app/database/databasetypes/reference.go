package databasetypes

type Reference struct {
	ID     string `json:"id"`
	Name   string `json:"name"`
	Entity string `json:"entity"`
}
